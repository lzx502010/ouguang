$(function(){
	var owl=$('#see');
 		 owl.owlCarousel({
			margin:0,
			responsiveClass: true,
			autoplay:false,
			loop:true,
			dots:false,
			nav:true,
			navText:['<span class="icon">&#xe6f3;</span>','<span class="icon">&#xe701;</span>'],
			items:1
		  })	
				
				
				
		$('#list').on('click','li .click',function(){
				$('#open1').addClass('active');
				var data='<div class="big"><img src="img/pp3.jpg" alt="" />\
					    <div class="pps">\
							<div class="pdt">现代极简</div><div   class="pdd">\
							化繁为简的卧室，以利落、干练的直线条为笔触，利用一板到顶的柜体设计，将现代美学与功能完美融合，每一寸皆精致呈现。<label>6666</label>\
						   </div> \
					   </div> \
				    </div> \
				     <div class="big"><img src="img/pp3.jpg" alt="" />\
					    <div class="pps">\
							<div class="pdt">现代极简</div><div class="pdd">\
							化繁为简的卧室，以利落、干练的直线条为笔触，利用一板到顶的柜体设计，将现代美学与功能完美融合，每一寸皆精致呈现。<label>6666</label>\
						   </div> \
					   </div>\
				    </div>';
				  owl.trigger('replace.owl.carousel',data);
				  owl.trigger('refresh.owl.carousel');
		})	

		$('#list').on('click','li .pp',function(){		 
				$('#open2').addClass('active')
               var  src=$(this).attr('data-url');
			 
			   $('#open2 iframe').attr('src',src)
		})			
		
		
		
         $('.modal').on('click',function(){
			 $(this).removeClass('active')
		 })		
         $('.close').on('click',function(){
			 $(this).parents('.modal').eq(0).removeClass('active')
		 })	  
 $('.modal').on('click','.cont',function(e){
	 e.stopPropagation();
 })
 

})