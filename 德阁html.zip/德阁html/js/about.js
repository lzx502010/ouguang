$(function(){
		 $('#team').owlCarousel({
			margin:18,
			responsiveClass: true,
			autoplay:false,
			loop:true,
			dots:false,
			nav:true,
			navText:['<span class="icon">&#xe6f3;</span>','<span class="icon">&#xe701;</span>'],
			responsive:{
			0:{
				items:2
			},
			800:{
				items:3
			},
			1000:{
				items:3
			}		
			}
		  })		
				
	
	
 	 var $aLi=$("#box>.mine");
	 var ss=$aLi.size();
    var $box=$('#box');
    var $gall=$('#mine');
    var $aLiWidth=$('.cont').eq(0).width();
	var currNum=0;
    // 设置盒子的宽度
    $box.width($aLi.length*100 + '%');
    for(var nn=0;nn<$aLi.length;nn++){ 
	$aLi.eq(nn).width(1/$aLi.length * 100 + '%');
    };
    // 初始化手指坐标点
    var startPoint = 0;
    var startEle = 0;
    $gall.on("touchstart",function(e){ 
	    startPoint = e.originalEvent.targetTouches[0].pageX;
        startEle =$box.offset().left;
    });
    //手指滑动
    $gall.on("touchmove",function(e){ 
	    var currPoint = e.originalEvent.targetTouches[0].pageX;
      if(startPoint-currPoint>30||startPoint-currPoint<-30){
           $box.css('left',startEle+currPoint-startPoint+ 'px');	
		}
    });
    //当手指抬起的时候，判断图片滚动离左右的距离，当
    $gall.on("touchend",function(e){ 
	   var left=$box.offset().left;
	   var ss=left+currNum*$aLiWidth;
	   if(ss>0){
		   if(currNum!=0){
             currNum =currNum-Math.ceil(ss/$aLiWidth);				   
		   }
	   }else{
	         currNum =currNum+Math.ceil(-ss/$aLiWidth);	   
	   }
        currNum=(currNum>=($aLi.length-1)?($aLi.length-1):currNum);
        currNum=(currNum<=0?0:currNum);
        $box.animate({'left':-currNum*$aLiWidth + 'px'},'300');
    })	
		
		
		
		
		
		$('#ctrols').find('a').mouseenter(function(){
			$(this).addClass('active').siblings('a').removeClass('active');
			$box.animate({'left':-$(this).index()*$aLiWidth + 'px'},'800');
		})
		
		
$('#tleft').click(function(){ 
          currNum--;
		  if(currNum<=0){currNum=0}
        $box.animate({'left':-currNum*$aLiWidth + 'px'},'300');
});     		
$('#tright').click(function(){ 
          currNum++;
		  if(currNum>=ss){currNum=(ss-1)}
        $box.animate({'left':-currNum*$aLiWidth + 'px'},'300');
});   		
		
 var e=0;
 var  bea=$('#bea');
 var num=bea.find('li').size()+1;
$('#tt2').click(function(){ 
          var size=bea.width()*0.167;
		   e--;e=e%(num-5);
        bea.children('.his').animate({'left':size*e+'px'}, 'normal'); 
});     
$('#tt1').click(function(){ 
          var size=bea.width()*0.167;
	       e++;e=(e-num+5)%(num-5);
           bea.children('.his').animate({'left':size*e+'px'}, 'normal'); 
});     
		
		
		
					 
         var    $winH = $(window).height();
           var   $img= $('#coco').children('li');
           var   $obj2=$('#obj2').offset();
           var   $obj3=$('#obj3').offset();
           var   $obj4=$('#obj4').offset();
           var   $obj5=$('#obj5').offset();
           var   $obj6=$('#obj6').offset();
           var   $obj7=$('#foot').offset();

		   
		   setTimeout(function(){
            $obj2=$('#obj2').offset();
            $obj3=$('#obj3').offset();
            $obj4=$('#obj4').offset();
            $obj5=$('#obj5').offset();
            $obj6=$('#obj6').offset();
            $obj7=$('#foot').offset();
		   },1000);

     $('#obj1,#main,#plays').addClass('active');	
			
  $(window).scroll(function(){
             $scro=$(window).scrollTop();
			if($scro<10){  
                $('#obj2,#obj3,#obj4,#obj5,#obj6,#control,#news,#team,#word,#mine,#foot').removeClass('active');	
			}else{    
			if($scro + $winH >= $obj2.top&&$scro<$obj2.top&&$('#obj2').hasClass('active')==false){$('#obj2,#control').addClass('active');		
			}
             if($scro + $winH >= $obj3.top&&$scro<$obj3.top&&$('#obj3').hasClass('active')==false){
				 $('#obj3,#news,#team').addClass('active');								 
			}	
             if($scro + $winH >= $obj4.top&&$scro<$obj4.top&&$('#obj4').hasClass('active')==false){
				 $('#obj4,#word').addClass('active');								 
			}	
             if($scro + $winH >= $obj5.top&&$scro<$obj5.top&&$('#obj5').hasClass('active')==false){
				 $('#obj5,#mine').addClass('active');								 
			}				
             if($scro + $winH >= $obj6.top&&$scro<$obj6.top&&$('#obj6').hasClass('active')==false){
				 $('#obj6').addClass('active');	
 				 $img.each(function(i){
					setTimeout(function(){
						$img.eq(i).addClass('active');
					},i*300);
				 });				 
			}
             if($scro + $winH >= $obj7.top&&$scro<$obj7.top&&$('#foot').hasClass('active')==false){
				 $('#foot').addClass('active');								 
			}					
		}
 });   		   
 				 
 

 
 
   $(window).on('resize', function(){
	  $winH = $(window).height();//获取窗口高度
            $obj2=$('#obj2').offset();
            $obj3=$('#obj3').offset();
            $obj4=$('#obj4').offset();
            $obj5=$('#obj5').offset();
            $obj6=$('#obj6').offset();
            $obj7=$('#foot').offset();
  });   
 

  
		
		

$(".mine  a").each(function(i){
var img = $(this);
var src=$(this).attr("href");
var realWidth=0;//真实的宽度
var realHeight=0;//真实的高度
$("<img/>").attr("src", src).load(function() {
realWidth = this.width;
realHeight = this.height;
	img.attr("data-size",realWidth+'x'+realHeight);
	img.attr("data-med-size",realWidth+'x'+realHeight);
});
});




            var initPhotoSwipeFromDOM = function(gallerySelector) {

                // parse slide data (url, title, size ...) from DOM elements 
                // (children of gallerySelector)
                var parseThumbnailElements = function(el) {
                    var thumbElements = el.childNodes,
                            numNodes = thumbElements.length,
                            items = [],
                            figureEl,
                            linkEl,
                            size,
                            item;

                    for (var i = 0; i < numNodes; i++) {

                        figureEl = thumbElements[i]; // <figure> element

                        // include only element nodes 
                        if (figureEl.nodeType !== 1) {
                            continue;
                        }

                        linkEl = figureEl.children[0]; // <a> element

                        size = linkEl.getAttribute('data-size').split('x');

                        // create slide object
                        item = {
                            src: linkEl.getAttribute('href'),
                            w: parseInt(size[0], 10),
                            h: parseInt(size[1], 10),
						   author: linkEl.getAttribute('data-author')
                        };



                        if (figureEl.children.length > 1) {
                            // <figcaption> content
                            item.title = figureEl.children[1].innerHTML;
                        }

                        if (linkEl.children.length > 0) {
                            // <img> thumbnail element, retrieving thumbnail url
                            item.msrc = linkEl.children[0].getAttribute('src');
                        }

                        item.el = linkEl; // save link to element for getThumbBoundsFn
                        items.push(item);
                    }

                    return items;
                };

                // find nearest parent element
                var closest = function closest(el, fn) {
                    return el && (fn(el) ? el : closest(el.parentNode, fn));
                };

                // triggers when user clicks on thumbnail
                var onThumbnailsClick = function(e) {
                    e = e || window.event;
                    e.preventDefault ? e.preventDefault() : e.returnValue = false;

                    var eTarget = e.target || e.srcElement;

                    // find root element of slide
                    var clickedListItem = closest(eTarget, function(el) {
                        return (el.tagName && el.tagName.toUpperCase() === 'LI');
                    });

                    if (!clickedListItem) {
                        return;
                    }

                    // find index of clicked item by looping through all child nodes
                    // alternatively, you may define index via data- attribute
                    var clickedGallery = clickedListItem.parentNode,
                            childNodes = clickedListItem.parentNode.childNodes,
                            numChildNodes = childNodes.length,
                            nodeIndex = 0,
                            index;

                    for (var i = 0; i < numChildNodes; i++) {
                        if (childNodes[i].nodeType !== 1) {
                            continue;
                        }

                        if (childNodes[i] === clickedListItem) {
                            index = nodeIndex;
                            break;
                        }
                        nodeIndex++;
                    }

                    if (index >= 0) {
                        // open PhotoSwipe if valid index found
                        openPhotoSwipe(index, clickedGallery);
                    }
                    return false;
                };

                // parse picture index and gallery index from URL (#&pid=1&gid=2)
                var photoswipeParseHash = function() {
                    var hash = window.location.hash.substring(1),
                            params = {};

                    if (hash.length < 5) {
                        return params;
                    }

                    var vars = hash.split('&');
                    for (var i = 0; i < vars.length; i++) {
                        if (!vars[i]) {
                            continue;
                        }
                        var pair = vars[i].split('=');
                        if (pair.length < 2) {
                            continue;
                        }
                        params[pair[0]] = pair[1];
                    }

                    if (params.gid) {
                        params.gid = parseInt(params.gid, 10);
                    }

                    return params;
                };

                var openPhotoSwipe = function(index, galleryElement, disableAnimation, fromURL) {
                    var pswpElement = document.querySelectorAll('.pswp')[0],
                            gallery,
                            options,
                            items;

                    items = parseThumbnailElements(galleryElement);

                    // define options (if needed)
                    options = {
                        // define gallery index (for URL)
                        galleryUID: galleryElement.getAttribute('data-pswp-uid'),
					   shareButtons: [
					   {id:'download', label:'保存图片', url:'{{raw_image_url}}', download:true},
					   {id:'wechat', label:'分享好友', url:'http://connect.qq.com/widget/shareqq/index.html?url={{url}}&media={{image_url}}&description={{text}}'},
					   {id:'weibo', label:'新浪微博', url:'http://service.weibo.com/share/share.php?text={{text}}&url={{url}}'}
					   ], // 分享按钮
                        getThumbBoundsFn: function(index) {
                            // See Options -> getThumbBoundsFn section of documentation for more info
                            var thumbnail = items[index].el.getElementsByTagName('img')[0], // find thumbnail
                                    pageYScroll = window.pageYOffset || document.documentElement.scrollTop,
                                    rect = thumbnail.getBoundingClientRect();

                            return {x: rect.left, y: rect.top + pageYScroll, w: rect.width};
                        },
						addCaptionHTMLFn: function(item, captionEl, isFake) {
								if(!item.title) {
									captionEl.children[0].innerText = '';
									return false;
								}
								captionEl.children[0].innerHTML = item.title +  '<small>' + item.author + '</small>';
								return true;
							}
                    };

                    // PhotoSwipe opened from URL
                    if (fromURL) {
                        if (options.galleryPIDs) {
                            // parse real index when custom PIDs are used 
                            // http://photoswipe.com/documentation/faq.html#custom-pid-in-url
                            for (var j = 0; j < items.length; j++) {
                                if (items[j].pid == index) {
                                    options.index = j;
                                    break;
                                }
                            }
                        } else {
                            // in URL indexes start from 1
                            options.index = parseInt(index, 10) - 1;
                        }
                    } else {
                        options.index = parseInt(index, 10);
                    }

                    // exit if index not found
                    if (isNaN(options.index)) {
                        return;
                    }

                    if (disableAnimation) {
                        options.showAnimationDuration = 0;
                    }

                    // Pass data to PhotoSwipe and initialize it
                    gallery = new PhotoSwipe(pswpElement, PhotoSwipeUI_Default, items, options);
                    gallery.init();
                };

                // loop through all gallery elements and bind events
                var galleryElements = document.querySelectorAll(gallerySelector);

                for (var i = 0, l = galleryElements.length; i < l; i++) {
                    galleryElements[i].setAttribute('data-pswp-uid', i + 1);
                    galleryElements[i].onclick = onThumbnailsClick;
                }

                // Parse URL and open gallery if it contains #&pid=3&gid=1
                var hashData = photoswipeParseHash();
                if (hashData.pid && hashData.gid) {
                    openPhotoSwipe(hashData.pid, galleryElements[ hashData.gid - 1 ], true, true);
                }
            };

		initPhotoSwipeFromDOM('.mine');	
		
 
});