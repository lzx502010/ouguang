$(function(){ 

 
    $('.banner').addClass('active');
 

 
 
 
 
    $(window).resize(function(){ 
      if($(window).width()<640){
		  $('#hold').removeClass('active');
		  $('#guide').removeClass('active');
	  }else{ 
		  $('#hold').addClass('active');
		  $('#guide').addClass('active');	
	  }
	});   
 

 
$('#hold').click(function(){
	$(this).toggleClass('active');
	$('#guide').toggleClass('active');
});
 
 
 
   _init_area();
 
 	  setTimeout(function(){
		  $('#up').slideDown()
	  },1000);	 
		 
		 $('#clos').click(function(){
			 $('#up').animate({left:-$('#up').innerWidth()+'px'},500)
		 });
 
 
	
})