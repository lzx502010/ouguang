$(function(){
			 $('#pro').owlCarousel({
			margin:110,
			responsiveClass: true,
			autoplay:false,
			loop:true,
			dots:false,
			nav:true,
			navText:['<span class="icon">&#xe6f3;</span>','<span class="icon">&#xe701;</span>'],
			items:1
		  })	
		  
	var owl=$('#see');
 		 owl.owlCarousel({
			margin:0,
			autoplay:false,
			loop:true,
			dots:false,
			nav:true,
			navText:['<span class="icon">&#xe6f3;</span>','<span class="icon">&#xe701;</span>'],
			items:1
		  })	
			 
         var    $winH = $(window).height();
           var   $img= $('#lead').children('a');
           var   $img2= $('#list').children('li');
           var   $obj1=$('#lead').offset();
           var   $obj2=$('#list').offset();
           var   $obj3=$('#foot').offset();

		   
		   setTimeout(function(){
              $obj1=$('#lead').offset();
              $obj2=$('#list').offset();
              $obj3=$('#foot').offset();
		   },1000);

 				 $img.each(function(i){
					setTimeout(function(){
						$img.eq(i).addClass('ac');
					},i*300);
				 });	
				 $('#pro').addClass('active');						
  $(window).scroll(function(){
             $scro=$(window).scrollTop();
			if($scro<10){  
                $('#foot,#list').removeClass('active');	
				$img2.removeClass('active');
			}else{ 
 
			if($scro + $winH >= $obj2.top&&$scro<$obj2.top&&$('#list').hasClass('active')==false){$('#list').addClass('active');		
				 $img2.each(function(i){
					setTimeout(function(){
						$img2.eq(i).addClass('active');
					},i*300);
				 });		
			}
             if($scro + $winH >= $obj3.top&&$scro<$obj3.top&&$('#foot').hasClass('active')==false){
				 $('#foot').addClass('active');								 
			}		   
		}
 });   		   
 
 
 

 
 
   $(window).on('resize', function(){
	  $winH = $(window).height();//获取窗口高度
              $obj1=$('#lead').offset();
              $obj2=$('#list').offset();
              $obj3=$('#foot').offset();
  });   
 

  		$('#list').on('click','li a',function(){
				$('#open1').addClass('active');
				var i=$(this).parents('li').eq(0).index();
				// var data='<div class="big"><img src="img/md.jpg" alt="" />\
					    // <div class="pps">\
							// <div class="pdt">现代极简</div><div   class="pdd">\
							// 化繁为简的卧室，以利落、干练的直线条为笔触，利用一板到顶的柜体设计，将现代美学与功能完美融合，每一寸皆精致呈现。<label>6666</label>\
						   // </div> \
					   // </div> \
				    // </div> \
				     // <div class="big"><img src="img/md.jpg" alt="" />\
					    // <div class="pps">\
							// <div class="pdt">现代极简</div><div class="pdd">\
							// 化繁为简的卧室，以利落、干练的直线条为笔触，利用一板到顶的柜体设计，将现代美学与功能完美融合，每一寸皆精致呈现。<label>6666</label>\
						   // </div> \
					   // </div>\
				    // </div>';
				  // owl.trigger('replace.owl.carousel',data);
				  // owl.trigger('refresh.owl.carousel');
				owl.trigger('to.owl.carousel',i);  
		})	
			 
			 		
         $('.modal').on('click',function(){
			 $(this).removeClass('active')
		 })		
         $('.close').on('click',function(){
			 $(this).parents('.modal').eq(0).removeClass('active')
		 })	  
 $('.modal').on('click','.cont',function(e){
	 e.stopPropagation();
 })
			 
 
});