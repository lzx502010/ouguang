$(function(){

$('#ads').fadeIn('slow');

	      $('#ad,#slider').width($(window).width()).height($(window).width()*0.4);
            var _SlideshowTransitions = [
            {$Duration:1200,x:0.3,$Cols:2,$SlideOut:true,$ChessMode:{$Column:3},$Easing:{$Left:$JssorEasing$.$EaseInCubic,$Opacity:$JssorEasing$.$EaseLinear},$Opacity:2}
            , { $Duration: 1000, x: -0.2, $Delay: 40, $Cols: 12, $SlideOut: true, $Formation: $JssorSlideshowFormations$.$FormationStraight, $Assembly: 260, $Easing: { $Left: $JssorEasing$.$EaseInOutExpo, $Opacity: $JssorEasing$.$EaseInOutQuad }, $Opacity: 2, $Outside: true, $Round: { $Top: 0.5} },
			{$Duration:700,$Opacity:2,$Brother:{$Duration:1000,$Opacity:2}},
           {$Duration:1200,x:0.3,y:-0.3,$Delay:60,$Zoom:1,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Easing:{$Left:$JssorEasing$.$EaseInJump,$Top:$JssorEasing$.$EaseInJump,$Opacity:$JssorEasing$.$EaseLinear},$Opacity:2,$Round:{$Left:0.8,$Top:0.8}},
		   {$Duration:1200,$Zoom:1,$Rotate:1,$During:{$Zoom:[0.2,0.8],$Rotate:[0.2,0.8]},$Easing:{$Zoom:$JssorEasing$.$EaseSwing,$Opacity:$JssorEasing$.$EaseLinear,$Rotate:$JssorEasing$.$EaseSwing},$Opacity:2,$Round:{$Rotate:0.5}}
            ];
			var _CaptionTransitions = [ 
            {$Duration:1800,y:-0.8,$Zoom:11,$Rotate:-1.5,$Easing:{$Top:$JssorEasing$.$EaseInOutElastic,$Zoom:$JssorEasing$.$EaseInElastic,$Rotate:$JssorEasing$.$EaseInOutElastic},$Opacity:2,$During:{$Zoom:[0,0.8],$Opacity:[0,0.7]},$Round:{$Rotate:0.5}},
            {$Duration:900,$Clip:3,$Easing:{$Clip:$JssorEasing$.$EaseInOutCubic},$Opacity:2},
            {$Duration:900,$Clip:4,$Move:true,$Easing:{$Clip:$JssorEasing$.$EaseInOutCubic}},
            {$Duration:900,y:0.6,$Zoom:11,$Easing:{$Top:$JssorEasing$.$EaseInCubic,$Zoom:$JssorEasing$.$EaseInCubic},$Opacity:2}
			];
			
			_CaptionTransitions['CLIP']={$Duration:1500,y:-0.8,$Easing:$JssorEasing$.$EaseInOutCubic,$Opacity:2,$During:{$Top:[0.4,0.6],$Opacity:[0.4,0.6]}};
			
			
            var options = {
			    $FillMode: 2,    
                $AutoPlay: true,                                    
                $AutoPlaySteps: 1,                                  
                $AutoPlayInterval: 3000,                        
                $PauseOnHover: 0,                     
                $ArrowKeyNavigation: true,   			     
                $SlideDuration: 500,                               
                $MinDragOffsetToSlide: 20,                                                
                $SlideSpacing: 0, 					        
                $DisplayPieces: 1,                          
                $ParkingPosition: 0,                                
                $UISearchMode: 1,                    
                $PlayOrientation: 1,                               
                $DragOrientation: 3,                              
                $SlideshowOptions: {                             
                    $Class: $JssorSlideshowRunner$,      
                    $Transitions: _SlideshowTransitions,
                    $TransitionsOrder: 1,                         
                    $ShowLink: true                                  
                },
			   $CaptionSliderOptions: {                   
                    $Class: $JssorCaptionSlider$,           
                    $CaptionTransitions: _CaptionTransitions,    
                    $PlayInMode: 1,                         
                    $PlayOutMode: 0      
                },
                $BulletNavigatorOptions: {                            
                    $Class: $JssorBulletNavigator$,                 
                    $ChanceToShow: 2,                         
                    $AutoCenter: 0,               
                    $Steps: 1,                        
                    $Lanes: 1,                        
                    $SpacingX: 10,                    
                    $SpacingY: 10,                 
                    $Orientation: 1                           
                },
                $ArrowNavigatorOptions: {
                    $Class: $JssorArrowNavigator$,         
                    $ChanceToShow: 2     }                         
            };
			
		var	  jssor_slider2 = new $JssorSlider$('ad', options);

		  $('#ad').children().eq(0).css('transform','');
			
            function ScaleSlider() {
				setTimeout(function(){
                var parentWidth = jssor_slider2.$Elmt.parentNode.clientWidth;
                if (parentWidth)
				{
					jssor_slider2.$ScaleWidth(Math.min(parentWidth, parentWidth));
				}
                    
                else{
					 window.setTimeout(ScaleSlider, 30);	
				}	
				},100);            	
            }

          
            $(window).bind("resize", ScaleSlider);
            $(window).bind("orientationchange", ScaleSlider);
			
			
		var $owl=$('#duct');
		var $owl2=$('#control');
		var $owl3=$('#gall');
		var $owl4=$('#plays');
		
		 $owl.owlCarousel({
					margin: 0,
					responsiveClass: true,
					autoplay:false,
					dots:false,
					nav:true,
					items:1,
					navText:['<span class="icon">&#xe6f3;</span>','<span class="icon">&#xe701;</span>']
				  })
				  
		 $owl2.owlCarousel({
					margin: 12,
					responsiveClass: true,
					autoplay:false,
					dots:false,
					responsive:{
					0:{
						items:3
					},
					800:{
						items:4
					},
					1000:{
						items:5
					}		
					}
				  })				  
 

		
         $owl.on('changed.owl.carousel', function(event) {
			  $owl2.trigger('to.owl.carousel',event.item.index)
			  $owl2.find('.owl-item').children().removeClass('active');
			  $owl2.find('.owl-item').eq(event.item.index).children().addClass('active');   
		   })   	
		   
		   $owl2.on('click','.owl-item',function() {
            var i=$(this).index();
			$owl.trigger('to.owl.carousel',i)  
		 })   	   




		 $owl3.owlCarousel({
			margin: 0,
			responsiveClass: true,
			autoplay:false,
			loop:true,
			dots:false,
			nav:true,
			navText:['<span class="icon">&#xe6f3;</span>','<span class="icon">&#xe701;</span>'],
			items:2
		  })	
		  
		 $('#team').owlCarousel({
			margin:12,
			responsiveClass: true,
			autoplay:false,
			loop:true,
			dots:false,
			nav:true,
			navText:['<span class="icon">&#xe6f3;</span>','<span class="icon">&#xe701;</span>'],
					responsive:{
					0:{
						items:3
					},
					800:{
						items:3
					},
					1000:{
						items:4
					}		
					}
		  })		
		  
		  $owl4.owlCarousel({
			autoplay:false,
			loop:true,
			dots:false,
			items:1
		  })		
		  
         $owl4.on('changed.owl.carousel', function(event) {
			 setTimeout(function(){
			  var i=$owl4.find('.owl-item.active').eq(0).children().attr('data-i');
			  $('#cntrol').children().eq(i).addClass('active').siblings().removeClass('active'); 
			 },100);
		   })   	
		  
		  
		  $('#cntrol').on('click','a',function(){
			  var i=$(this).index();
			$owl4.trigger('to.owl.carousel',i)  
		  })
		 
		 $('#news').owlCarousel({
					margin:10,
					responsiveClass: true,
					loop:false,
					autoplay:false,
					dots:false,
					nav:true,
					items:2,
					navText:['<span class="icon">&#xe6f3;</span>','<span class="icon">&#xe701;</span>']
				  })	
		 

		 
           var    $winH = $(window).height();
           var   $img= $('#list').children('li');
           var   $img2= $('#coco').children('li');
           var   $img3= $('#step').children('li');
           var   $img4= $('#lead').children('a');
           var   $obj1=$('#obj1').offset();
           var   $obj2=$('#obj2').offset();
           var   $obj3=$('#obj3').offset();
           var   $obj4=$('#obj4').offset();
           var   $obj5=$('#obj5').offset();
           var   $obj6=$('#obj6').offset();
           var   $obj7=$('#obj7').offset();  
           var   $obj8=$('#obj8').offset();  
           var   $obj9=$('#foot').offset(); 
 
		   
		   setTimeout(function(){
				$obj1=$('#obj1').offset();
				$obj2=$('#obj2').offset();
				$obj3=$('#obj3').offset();
				$obj4=$('#obj4').offset();
				$obj5=$('#obj5').offset();
				$obj6=$('#obj6').offset();
				$obj7=$('#obj7').offset();  
				$obj8=$('#obj8').offset();   
				$obj9=$('#foot').offset();  
		   },1000);

 
			
  $(window).scroll(function(){
             $scro=$(window).scrollTop();
			if($scro<10){  
                $('#obj1,#obj2,#obj3,#obj4,#obj5,#obj6,#obj7,#obj8,#foot,#kind,#team,#plays,#news').removeClass('active');
				 $owl.removeClass('active');		
				 $owl2.removeClass('active');		
				 $owl3.removeClass('active');		
				$img.removeClass('active');
				$img2.removeClass('active');
				$img3.removeClass('active');
				$img4.removeClass('ac');
			}else{ 
            if($scro + $winH >= $obj1.top&&$scro<$obj1.top&&$('#obj1').hasClass('active')==false){
			 $('#obj1').addClass('active');		
			 $owl.addClass('active');			$owl2.addClass('active');			 
			}      
			if($scro + $winH >= $obj2.top&&$scro<$obj2.top&&$('#obj2').hasClass('active')==false){$('#obj2').addClass('active');		
			$owl3.addClass('active');			
			}
             if($scro + $winH >= $obj3.top&&$scro<$obj3.top&&$('#obj3').hasClass('active')==false){
				 $('#obj3,#kind').addClass('active');	
				 $img.each(function(i){
					setTimeout(function(){
						$img.eq(i).addClass('active');
					},i*300);
				 });								 
			}		
             if($scro + $winH >= $obj4.top&&$scro<$obj4.top&&$('#obj4').hasClass('active')==false){$('#obj4').addClass('active');	
				 $img2.each(function(i){
					setTimeout(function(){
						$img2.eq(i).addClass('active');
					},i*300);
				 });	
			}			
            if($scro + $winH >= $obj5.top&&$scro<$obj5.top&&$('#obj5').hasClass('active')==false){$('#obj5,#team').addClass('active');

           	}					
            if($scro + $winH >= $obj6.top&&$scro<$obj6.top&&$('#obj6').hasClass('active')==false){$('#obj6,#plays').addClass('active');		
			}		
            if($scro + $winH >= $obj7.top&&$scro<$obj7.top&&$('#obj7').hasClass('active')==false){ $('#obj7,#news').addClass('active');
				 $img4.each(function(i){
					setTimeout(function(){
						$img4.eq(i).addClass('ac');
					},i*300);
				 });	
		   }		
            if($scro + $winH >= $obj8.top&&$scro<$obj8.top&&$('#obj8').hasClass('active')==false){$('#obj8').addClass('active');		
		 	 $img3.each(function(i){
				setTimeout(function(){
				    $img3.eq(i).addClass('active');
				},i*300);
             });		
		   }		
            if($scro + $winH >= $obj9.top&&$scro<$obj9.top&&$('#foot').hasClass('active')==false){$('#foot').addClass('active');	
 
		   }				   
		}
 });   		   
 
  $('#open2 iframe').css('min-width','80%').css('min-height',$('.big iframe').width()*0.6+'px')
 

 
 
   $(window).on('resize', function(){
	   setTimeout(function(){
			  $winH = $(window).height();//获取窗口高度
				$obj1=$('#obj1').offset();
				$obj2=$('#obj2').offset();
				$obj3=$('#obj3').offset();
				$obj4=$('#obj4').offset();
				$obj5=$('#obj5').offset();
				$obj6=$('#obj6').offset();
				$obj7=$('#obj7').offset();  
				$obj8=$('#obj8').offset();  
				$obj9=$('#foot').offset(); 
		 $('#open2 iframe').css('min-width','80%').css('min-height',$('.big iframe').width()*0.6+'px')		   
	   },1000);
  });   
 

 
 
      $('#duct').on('click','#play',function(){
		 
		  $('#open2').addClass('active')
	  })
         $('#open2l').on('click',function(){
			 $(this).removeClass('active')
		 })		
         $('.close').on('click',function(){
			 $(this).parents('.modal').eq(0).removeClass('active')
		 })	  
 $('#open2').on('click','.cont',function(e){
	 e.stopPropagation();
 })
 

})